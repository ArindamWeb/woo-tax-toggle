jQuery(document).ready(function($) {
    $('#tax_toggle, #tax_toggle_cart').change(function() {
        var includeTax = $(this).prop('checked');
        updatePrices(includeTax);
    });

    function updatePrices(includeTax) {
        $.ajax({
            type: 'POST',
            url: ajax_object.ajax_url,
            data: {
                action: 'update_prices',
                include_tax: includeTax
            },
            success: function(response) {
                if (response.success) {
                    if ($('#tax_toggle').length) {
                        // Single product page
                        $('p.price').html(response.prices.single_product);
                    } else if ($('#tax_toggle_cart').length) {
                        // Cart page
                        $.each(response.prices, function(cart_item_key, price) {
                            $('div[data-cart_item_key="' + cart_item_key + '"] .product-price').html(price);
                        });
                    }
                } else {
                    console.log('Error updating prices');
                }
            },
            error: function(xhr, textStatus, errorThrown) {
                console.log('Error: ' + errorThrown);
            }
        });
    }
});
