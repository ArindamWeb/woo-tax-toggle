<?php
/*
 * Plugin Name:       Tax Toggle
 * Plugin URI:        https://example.com/plugins/the-basics/
 * Description:       Handle the basics with this plugin.
 * Version:           1.0
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Arindam Mallick
 * Author URI:        http://localhost/tax-toggle
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Update URI:        https://example.com/my-plugin/
 * Text Domain:       tax-toggle
 */



if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Add the toggle buttons to the front end
function wctt_add_tax_toggle_buttons() {
    echo '<div id="tax-toggle-buttons">';
    echo '<button id="tax-toggle-button" onclick="toggleTax()">Toggle Tax</button>';
    //echo '<button id="reset-tax-button" onclick="resetTax()">Back to Inclusive Price</button>';
    echo '</div>';
}
add_action('wp_footer', 'wctt_add_tax_toggle_buttons');

// Enqueue the script and style to handle the toggle
function wctt_enqueue_scripts() {
    wp_enqueue_script('wctt-script', plugin_dir_url(__FILE__) . 'wctt-script.js', array('jquery'), '1.1', true);
    wp_localize_script('wctt-script', 'wctt_ajax', array('ajax_url' => admin_url('admin-ajax.php')));
    wp_enqueue_style('wctt-style', plugin_dir_url(__FILE__) . 'wctt-style.css');
}
add_action('wp_enqueue_scripts', 'wctt_enqueue_scripts');

// Handle the AJAX request to toggle tax
function wctt_toggle_tax() {
    if (isset($_POST['action_type'])) {
        if ($_POST['action_type'] === 'toggle') {
            $show_tax = get_option('woocommerce_prices_include_tax') === 'yes' ? 'no' : 'yes';
            update_option('woocommerce_prices_include_tax', $show_tax);
        } elseif ($_POST['action_type'] === 'reset') {
            update_option('woocommerce_prices_include_tax', 'yes');
        }
        wp_send_json_success();
    }
    wp_send_json_error();
}
add_action('wp_ajax_wctt_toggle_tax', 'wctt_toggle_tax');
add_action('wp_ajax_nopriv_wctt_toggle_tax', 'wctt_toggle_tax');