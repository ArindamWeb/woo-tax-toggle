jQuery(document).ready(function($) {
    window.toggleTax = function() {
        $.post(wctt_ajax.ajax_url, {
            action: 'wctt_toggle_tax',
            action_type: 'toggle'
        }, function(response) {
            if (response.success) {
                location.reload();
            } else {
                alert('Failed to toggle tax.');
            }
        });
    }

    window.resetTax = function() {
        $.post(wctt_ajax.ajax_url, {
            action: 'wctt_toggle_tax',
            action_type: 'reset'
        }, function(response) {
            if (response.success) {
                location.reload();
            } else {
                alert('Failed to reset tax.');
            }
        });
    }
});
